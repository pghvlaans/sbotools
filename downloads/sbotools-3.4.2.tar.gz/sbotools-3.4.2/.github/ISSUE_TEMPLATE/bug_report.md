---
name: Bug report
about: Basic information to include
title: ''
labels: ''
assignees: pghvlaans

---

* Command entered:

* Output of `cat /etc/slackware-version`:

* Output of `sboconfig --version`:

* Output of `sboconfig --list`:

* Output of `sbohints --list` (version 3.4 and later):

* Description:
