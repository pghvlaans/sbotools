---
name: Bug report
about: Basic information to include
title: ''
labels: ''
assignees: pghvlaans

---

* Command entered:

* Output of `cat /etc/slackware-version`:

* Output of `sboconfig -v`:

* Output of `sboconfig -l | grep -ve sboconfig -e FALSE` (version 3.6 and earlier):

* Output of `sboconfig -n` (version 3.7 and later):

* Output of `sbohints -l` (version 3.4 and later):

* Output of `grep "# Updated" /etc/sbotools/obsolete` (version 3.6 and later):

* For `--compat32` failures, please copy and paste the last several lines of build output:

* Description:
