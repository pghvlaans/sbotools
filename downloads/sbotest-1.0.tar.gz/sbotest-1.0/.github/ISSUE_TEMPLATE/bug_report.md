---
name: Bug report
about: Basic information to include
title: ''
labels: ''
assignees: pghvlaans

---

* Command entered:

* Output of `cat /etc/slackware-version`:

* Output of `sbotest -v`:

* Output of `sbotest config -n`:

* Output of `sbotest hints -l`:

* Description:
