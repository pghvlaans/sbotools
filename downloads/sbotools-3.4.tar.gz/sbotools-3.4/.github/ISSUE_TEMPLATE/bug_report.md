---
name: Bug report
about: Basic information to include
title: ''
labels: ''
assignees: pghvlaans

---

* Command entered:

* Running version of `sbotools`:

* Output of `cat /etc/slackware-version`:

* Output of `sboconfig --list`:

* Output of `sbohints --list`, if you have it:

* Description:
