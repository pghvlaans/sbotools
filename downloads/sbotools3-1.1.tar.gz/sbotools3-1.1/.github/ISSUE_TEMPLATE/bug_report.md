---
name: Bug report
about: Basic information to include
title: ''
labels: ''
assignees: pghvlaans

---

* Running version of `sbotools3`:

* Output of `cat /etc/slackware-version`:

* Output of `sboconfig --list`:

* Description:
